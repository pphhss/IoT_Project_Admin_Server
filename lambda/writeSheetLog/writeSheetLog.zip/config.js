module.exports = {
    npd: {
        host: "iot-db-instance.chxlgclnkisp.ap-northeast-2.rds.amazonaws.com",
        user: "admin",
        password: "dudghdudgh1!",
        database: "IOT"
    },
    power:50
};